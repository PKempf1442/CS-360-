//Set package
package com.example.project2weightlossapp;

//Import modules
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class CRUDModule extends SQLiteOpenHelper {
    //Database name and version
    private static final String DATABASE_NAME = "weightLoss.db";
    private static final int DATABASE_VERSION = 1;

    //Table name and columns
    private static final String TABLE_NAME = "weight_entries";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_WEIGHT = "weight";

    //Define create table
    private static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_WEIGHT + " REAL)";

    //Crud module constructor
    public CRUDModule(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    //On create method to create sql table
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }
    //Check for updates and update if available
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
    //Create
    //Insert weight
    public boolean insertWeight(float weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT, weight);

        long result = db.insert(TABLE_NAME, null, values);
        db.close();
        return result != -1;
    }
    //Read
    public Cursor getAllWeights() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }
    //Update
    public boolean updateWeight(int id, float newWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT, newWeight);

        int rowsAffected = db.update(TABLE_NAME, values, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return rowsAffected > 0;
    }
    //Delete
    public void deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }

}
