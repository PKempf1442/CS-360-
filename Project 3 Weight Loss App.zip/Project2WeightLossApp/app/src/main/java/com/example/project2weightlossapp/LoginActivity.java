//Set package
package com.example.project2weightlossapp;

//Import modules
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.HashMap;
import java.util.Objects;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

//LoginActivity class
public class LoginActivity extends AppCompatActivity {
    //Constant for sms permissions
    private static final int SMS_PERMISSION_REQUEST_CODE = 101;

    //Variables for username and password
    private EditText usernameEditText, passwordEditText;
    //Hashmap for accounts
    private HashMap<String, String> userAccounts = new HashMap<>();
    //Override method
    @Override
    //onCreate method
    protected void onCreate(Bundle savedInstanceState) {
        //Call onCreate
        super.onCreate(savedInstanceState);
        //Set layout
        setContentView(R.layout.login_layout);
        //Get user input for username and password
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        //Sms request

    }
    //sms request method
    public void requestSmsPermission(View view) {
        //Check if permission was already granted and request permission if it was not
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE);
            //If permission was granted return that it was
        } else {
            Toast.makeText(this, "SMS permission already granted", Toast.LENGTH_SHORT).show();
        }
    }
    //Method to check if sms permissions where allowed or denied
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        //Get result
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            //If granted parse to package manager
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
                //If not granted return that it was denied
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    //Login method
    public void login(View view) {
        //Get username and password
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();
        //Check if fields are empty
        if (!username.isEmpty() && !password.isEmpty()) {
            //If not empty check if valid
            if (userAccounts.containsKey(username) && Objects.equals(userAccounts.get(username), password)) {
                //If valid print login successful and start up data entry page
                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, DataActivity.class));
                //Else return invalid username or password
            } else {
                Toast.makeText(this, "Invalid Username or Password", Toast.LENGTH_SHORT).show();
            }
            //If empty, request user to input username and password
        } else {
            Toast.makeText(this, "Please enter both a username and password", Toast.LENGTH_SHORT).show();
        }
    }
    //createAccountMethod
    public void createAccount(View view) {
        //Get username and password
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();
        //Check if fields are empty and ask for input if they are
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both a username and password", Toast.LENGTH_SHORT).show();
            return;
        }
        //Check if username exists already
        if (userAccounts.containsKey(username)) {
            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            //If username does not exist add account to hashmap
        } else {
            userAccounts.put(username, password);
            Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();

            // Clear the input fields
            usernameEditText.setText("");
            passwordEditText.setText("");
        }
    }
}