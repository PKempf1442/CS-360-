package com.example.project2weightlossapp;

//Import modules
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class DataActivity extends AppCompatActivity {
    //Variables
    private EditText dataField;
    private GridView gridView;
    private ArrayList<String> dataList;
    private ArrayAdapter<String> adapter;
    private CRUDModule dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_layout);

        //Initialize grid and entry field
        dataField = findViewById(R.id.dataField);
        gridView = findViewById(R.id.gridView);

        //Initialize database helper
        dbHelper = new CRUDModule(this);

        //Initialize array and adapter
        dataList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dataList);
        gridView.setAdapter(adapter);

        //Load existing data from the database
        loadData();
    }

    //Add data method updated to use sql database
    public void addData(View view) {
        //Save data to database
        try {
            //Get weight from data field
            float number = Float.parseFloat(dataField.getText().toString());
            //Insert the weight into the database
            boolean inserted = dbHelper.insertWeight(number);
            //If successful return weight added
            if (inserted) {
                Toast.makeText(this, "Weight added", Toast.LENGTH_SHORT).show();
                dataField.setText("");
                //Refresh the data Field with the updated data
                loadData();
                //If unsuccessful return error
            } else {
                Toast.makeText(this, "Error adding weight", Toast.LENGTH_SHORT).show();
            }
        //Catch invalid inputs
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid number", Toast.LENGTH_SHORT).show();
        }
    }

    //Load data from the database
    private void loadData() {
        //Clear the list
        dataList.clear();
        //Get all weights
        Cursor cursor = dbHelper.getAllWeights();
        //Check if there are any records
        if (cursor.moveToFirst()) {
            //Iterate through the data
            do {
                int id = cursor.getInt(0);
                float weight = cursor.getFloat(1);
                //Format the data
                dataList.add(id + ": " + weight + " lbs");
                //continue iterating until the end of the data is reached
            } while (cursor.moveToNext());
        }
        //Update the data set
        adapter.notifyDataSetChanged();
    }
    // Update data method
    public void updateData(View view) {
        try {
            //Get the ID and weight from data field split with :
            String[] input = dataField.getText().toString().split(":");
            //Check to make sure there are 2 elements, ID and weight
            if (input.length == 2) {
                //Get the trimmed ID
                int id = Integer.parseInt(input[0].trim());
                //Get the new trimmed weight
                float newWeight = Float.parseFloat(input[1].trim());

                //Call the update method
                boolean updated = dbHelper.updateWeight(id, newWeight);
                //If successfully updated return that to user
                if (updated) {
                    Toast.makeText(this, "Weight updated", Toast.LENGTH_SHORT).show();
                    //Clear the data field
                    dataField.setText("");
                    //Refresh the data field with the updated data
                    loadData();
                    //Else return error
                } else {
                    Toast.makeText(this, "Error updating weight", Toast.LENGTH_SHORT).show();
                }
                //If the data is invalid return an error
            } else {
                Toast.makeText(this, "Please enter ID:Weight", Toast.LENGTH_SHORT).show();
            }
            //Catch for invalid inputs
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid ID and weight", Toast.LENGTH_SHORT).show();
        }
    }

    //Delete data method
    public void deleteData(View view) {

        try {
            //Get the ID input into the data field
            int id = Integer.parseInt(dataField.getText().toString());
            //Delete it
            dbHelper.deleteWeight(id);
            //Return that it was deleted
            Toast.makeText(this, "Weight deleted", Toast.LENGTH_SHORT).show();
            //Clear that data point on the grid
            dataField.setText("");
            //Refresh the grid
            loadData();
        //Catch to make sure ID is valid
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid item number", Toast.LENGTH_SHORT).show();
        }
    }
}
